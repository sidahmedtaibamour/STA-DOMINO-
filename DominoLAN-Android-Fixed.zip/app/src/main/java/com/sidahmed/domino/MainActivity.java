package com.sidahmed.domino;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowManager;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private LocalLanServer server;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.setBackgroundColor(0xff06100c);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        server = new LocalLanServer(this);
        web.addJavascriptInterface(new LanBridge(), "AndroidLan");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private void event(String type, String id, String data) {
        if (web == null) return;
        final String js = "window.onLanServerEvent && window.onLanServerEvent(" + JSONObject.quote(type) + "," + JSONObject.quote(id == null ? "" : id) + "," + JSONObject.quote(data == null ? "" : data) + ");";
        runOnUiThread(() -> { if(web != null) web.evaluateJavascript(js, null); });
    }
    private class LanBridge {
        @JavascriptInterface public void startServer() { if(server != null) server.start(); }
        @JavascriptInterface public void stopServer() { if(server != null) server.stop(); }
        @JavascriptInterface public void send(String id, String json) { if(server != null) server.send(id, json); }
        @JavascriptInterface public void closeClient(String id) { if(server != null) server.closeClient(id); }
    }
    void onLanEvent(String type, String id, String data) { event(type,id,data); }
    @Override public void onBackPressed() { if(web != null) web.evaluateJavascript("window.Nav && Nav.back()", null); else super.onBackPressed(); }
    @Override protected void onDestroy() { if(server != null) server.stop(); if(web != null) { web.destroy(); web = null; } super.onDestroy(); }
}
