package com.sidahmed.domino;

import android.util.Base64;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;

final class LocalLanServer {
    private final MainActivity activity;
    private volatile boolean running = false;
    private ServerSocket server;
    private Thread acceptThread;
    private final Map<String, Client> clients = new ConcurrentHashMap<>();
    private int nextId = 1;
    LocalLanServer(MainActivity a) { activity = a; }
    synchronized void start() {
        if (running) return;
        try {
            server = new ServerSocket(); server.setReuseAddress(true); server.bind(new InetSocketAddress(8765)); running = true;
            acceptThread = new Thread(() -> { while(running) { try { Socket s=server.accept(); s.setTcpNoDelay(true); String id=String.valueOf(nextId++); Client c=new Client(id,s); clients.put(id,c); new Thread(c,"domino-ws-"+id).start(); } catch(Exception e) { if(running) activity.onLanEvent("error","",e.toString()); } } },"domino-lan-accept"); acceptThread.start();
            activity.onLanEvent("server","","started");
        } catch(Exception e) { running=false; activity.onLanEvent("error","",e.toString()); }
    }
    synchronized void stop() { running=false; try{if(server!=null)server.close();}catch(Exception ignored){} for(Client c:new ArrayList<>(clients.values()))c.close(); clients.clear(); }
    void send(String id,String json) { Client c=clients.get(id); if(c!=null)c.sendText(json); }
    void closeClient(String id) { Client c=clients.get(id); if(c!=null)c.close(); }
    private final class Client implements Runnable {
        final String id; final Socket socket; InputStream in; OutputStream out; volatile boolean open=true; boolean handshaken=false;
        Client(String i,Socket s){id=i;socket=s;}
        public void run(){ try { in=socket.getInputStream();out=socket.getOutputStream(); handshake(); while(open){String msg=readFrame();if(msg==null)break;activity.onLanEvent("message",id,msg);} }catch(Exception ignored){} finally{close();} }
        void handshake() throws Exception {
            ByteArrayOutputStream b=new ByteArrayOutputStream(); int state=0, prev=-1; while(b.size()<8192){int x=in.read();if(x<0)throw new EOFException();b.write(x); if(prev==13&&x==10&&state==0)state=1; else if(prev==10&&x==13&&state==1)state=2; else if(prev==13&&x==10&&state==2){String q=b.toString("ISO-8859-1"); if(q.endsWith("\r\n\r\n"))break; state=0;} prev=x; if(b.size()>=4&&b.toString("ISO-8859-1").endsWith("\r\n\r\n"))break; }
            String req=b.toString("ISO-8859-1"); String key=null; for(String line:req.split("\r\n"))if(line.toLowerCase(Locale.ROOT).startsWith("sec-websocket-key:"))key=line.substring(line.indexOf(':')+1).trim(); if(key==null)throw new IOException("Missing websocket key");
            String accept=Base64.encodeToString(MessageDigest.getInstance("SHA-1").digest((key+"258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.ISO_8859_1)),Base64.NO_WRAP);
            out.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: "+accept+"\r\n\r\n").getBytes(StandardCharsets.ISO_8859_1));out.flush();handshaken=true;activity.onLanEvent("connect",id,"");
        }
        String readFrame() throws Exception {
            int a=in.read();if(a<0)return null;int b=in.read();if(b<0)return null;int opcode=a&15;long len=b&127;if(len==126)len=((in.read()&255)<<8)|(in.read()&255);else if(len==127){len=0;for(int i=0;i<8;i++)len=(len<<8)|(in.read()&255);} if(len>262144)throw new IOException("Frame too large"); boolean masked=(b&128)!=0;byte[] mask=new byte[4];if(masked)readFully(mask);byte[] payload=new byte[(int)len];readFully(payload);if(masked)for(int i=0;i<payload.length;i++)payload[i]^=mask[i%4];if(opcode==8){return null;}if(opcode==9){writeFrame(10,payload);return "{\"t\":\"ping\"}";}if(opcode!=1)return "";return new String(payload,StandardCharsets.UTF_8);
        }
        void readFully(byte[] a)throws IOException{int off=0;while(off<a.length){int n=in.read(a,off,a.length-off);if(n<0)throw new EOFException();off+=n;}}
        synchronized void sendText(String text){try{if(open&&handshaken)writeFrame(1,text.getBytes(StandardCharsets.UTF_8));}catch(Exception e){close();}}
        synchronized void writeFrame(int op,byte[] p)throws IOException{if(!open)return;out.write(0x80|op);if(p.length<126)out.write(p.length);else if(p.length<=65535){out.write(126);out.write((p.length>>8)&255);out.write(p.length&255);}else{out.write(127);for(int i=7;i>=0;i--)out.write((long)p.length>>(8*i)&255);}out.write(p);out.flush();}
        void close(){if(!open)return;open=false;clients.remove(id);try{socket.close();}catch(Exception ignored){}if(handshaken)activity.onLanEvent("close",id,"");}
    }
}
