# نسخة الويب من «دومينو» — كيف تظهر كموقع؟

الملف المضغوط (zip) **لا يُعرض كموقع** وحده؛ GitHub لا يفكّ الضغط تلقائيًا. عندك طريقتان:

## الطريقة ١ (الأبسط): ارفع الملفات مفكوكة
1. فكّ الضغط على هاتفك (تطبيق Files من Google أو ZArchiver)، أو نزّل الملفات واحدًا واحدًا من المحادثة.
2. في المستودع `sidahmedtaibamour.github.io`: **Add file ← Upload files**، اختر **كل** الملفات معًا:
   `index.html` · `manifest.json` · `sw.js` · `icon-180.png` · `icon-192.png` · `icon-512.png` · `icon-maskable-512.png` · `privacy.html` · `robots.txt` · `sitemap.xml`
3. اضغط **Commit changes**، وبعد دقيقة افتح `https://sidahmedtaibamour.github.io`.
> إن لم تُرد إلا اللعبة فارفع `index.html` وحده؛ ستعمل، لكن بدون أيقونة التثبيت وخدمة العمل دون اتصال.

## الطريقة ٢: ارفع الـ zip وسيفكّه GitHub بنفسه
1. ارفع `domino-web.zip` **باسمه نفسه** إلى جذر المستودع.
2. أنشئ الملف `.github/workflows/deploy-web.yml` بمحتوى الملف المرفق `deploy-web.yml`.
3. من **Settings ← Pages ← Build and deployment ← Source** اختر **GitHub Actions** (مرة واحدة).
4. افتح **Actions** وانتظر ✔؛ عندها يظهر الموقع. وكل مرة ترفع zip جديدًا يُنشر تلقائيًا.

## بعد النشر
- وسم Google (`google-site-verification`) موجود في أول `<head>` داخل `index.html`. افحص الرابط في Search Console واطلب الفهرسة ليظهر الوصف الجديد.
- **آيفون:** Safari ← مشاركة ← «إضافة إلى الشاشة الرئيسية». **أندرويد (Chrome):** القائمة ← «تثبيت التطبيق».
- الرابط الأساسي (canonical) مضبوط على `https://sidahmedtaibamour.github.io/`؛ إن غيّرت المسار فعدّله في `index.html` و`sitemap.xml` و`robots.txt`.
